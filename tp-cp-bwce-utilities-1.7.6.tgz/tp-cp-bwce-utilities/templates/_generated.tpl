{{/*
Copyright © 2025. Cloud Software Group, Inc.
This file is subject to the license terms contained
in the license file that is distributed with this file.
*/}}

{{- define "tp-cp-bwce-utilities.generated.buildNumber" }}latest{{end -}}
{{- define "tp-cp-bwce-utilities.generated.buildTimestamp" }}05-23-23_22.24.00_PM{{end -}}
